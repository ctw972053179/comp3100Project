import bf.BFClient;
class TestBF {
    public static void main(String[] args) {
        BFClient c = new BFClient();
        c.run();
    }
}
