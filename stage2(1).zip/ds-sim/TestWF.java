import wf.WFClient;
class TestWF {
    public static void main(String[] args) {
        WFClient c = new WFClient();
        c.run();
    }
}
