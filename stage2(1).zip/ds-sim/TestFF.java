import ff.FFClient;
class TestFF {
    public static void main(String[] args) {
        FFClient c = new FFClient();
        c.run();
    }
}
