#!/bin/bash
make clean
make
echo "Test All"
echo "./testff.sh TestFF.class"
./tests2.sh TestFF.class ff
echo "./testbf.sh TestBF.class"
./tests2.sh TestBF.class bf
echo "./testwf.sh TestWF.class"
./tests2.sh TestWF.class wf
